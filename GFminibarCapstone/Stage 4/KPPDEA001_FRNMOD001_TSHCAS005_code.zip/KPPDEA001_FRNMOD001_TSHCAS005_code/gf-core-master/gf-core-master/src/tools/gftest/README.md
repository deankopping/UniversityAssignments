Development moved to https://github.com/GrammaticalFramework/gftest
