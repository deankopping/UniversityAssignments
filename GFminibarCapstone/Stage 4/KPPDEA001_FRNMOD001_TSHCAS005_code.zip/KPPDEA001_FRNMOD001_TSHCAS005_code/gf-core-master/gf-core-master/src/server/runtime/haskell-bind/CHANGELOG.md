## 1.3.0

- Add completion support.

## 1.2.1

- Remove deprecated `pgf_print_expr_tuple`.
- Added an API for cloning expressions/types/literals.

## 1.2.0

- Stop `pgf-shell` from being built by default.
- parseToChart also returns the category.
- bugfix in bracketedLinearize.

## 1.1.0

- Remove SG library.

## 1.0.0

- Everything up until 2020-07-11.
