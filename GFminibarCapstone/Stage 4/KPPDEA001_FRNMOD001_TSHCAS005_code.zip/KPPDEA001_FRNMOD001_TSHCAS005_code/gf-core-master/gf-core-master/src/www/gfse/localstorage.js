
//Needs ../js/localstorage.js

var local=appLocalStorage("gf.editor.simple.grammar")
