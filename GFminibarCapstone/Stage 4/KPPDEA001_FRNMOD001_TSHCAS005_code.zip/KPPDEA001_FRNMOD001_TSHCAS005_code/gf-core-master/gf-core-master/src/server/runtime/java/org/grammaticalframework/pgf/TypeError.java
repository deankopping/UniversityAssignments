package org.grammaticalframework.pgf;

public class TypeError extends Exception {
	public TypeError(String message) {
		super(message);
	}
}
