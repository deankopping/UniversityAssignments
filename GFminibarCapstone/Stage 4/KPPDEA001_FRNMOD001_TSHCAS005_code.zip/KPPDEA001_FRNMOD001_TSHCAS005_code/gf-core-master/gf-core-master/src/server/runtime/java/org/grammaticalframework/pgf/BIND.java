package org.grammaticalframework.pgf;

public class BIND {
	private BIND() {
	}
	
	public static final BIND instance = new BIND();
}
