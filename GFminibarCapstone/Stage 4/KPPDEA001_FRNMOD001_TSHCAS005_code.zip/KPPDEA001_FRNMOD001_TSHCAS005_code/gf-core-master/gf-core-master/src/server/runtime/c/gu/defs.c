#include <gu/defs.h>

void* const gu_null = NULL;
GU_API GuStruct* const gu_null_struct = NULL;
