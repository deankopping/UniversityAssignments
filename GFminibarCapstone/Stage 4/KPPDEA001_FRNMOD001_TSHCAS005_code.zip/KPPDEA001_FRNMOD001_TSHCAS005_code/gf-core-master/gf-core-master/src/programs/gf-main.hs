module Main where

import qualified GF

main = GF.main
