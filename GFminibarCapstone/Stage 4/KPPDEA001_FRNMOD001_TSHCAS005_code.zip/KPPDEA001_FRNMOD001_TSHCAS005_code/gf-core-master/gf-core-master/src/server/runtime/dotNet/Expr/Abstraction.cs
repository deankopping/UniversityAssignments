using System;
using System.Runtime.InteropServices;

namespace PGFSharp
{
	/*public class Abs : Expression
	{
		public Abs ()
		{
		}
	}
*/

}

