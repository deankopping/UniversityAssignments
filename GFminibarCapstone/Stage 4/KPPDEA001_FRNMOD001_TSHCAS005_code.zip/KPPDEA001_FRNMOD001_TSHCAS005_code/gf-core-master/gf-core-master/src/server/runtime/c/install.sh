bash setup.sh configure
bash setup.sh build
bash setup.sh install
