select * from offices;
