#include <gu/fun.h>
