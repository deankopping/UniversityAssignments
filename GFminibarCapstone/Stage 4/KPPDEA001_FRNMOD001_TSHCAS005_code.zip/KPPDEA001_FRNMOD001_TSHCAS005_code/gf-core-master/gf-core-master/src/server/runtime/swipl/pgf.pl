:- module(pgf, [ readPGF/2, language/3 ]).
:- use_foreign_library(foreign('./swipgf.so')).
