#ifndef HOPU_H
#define HOPU_H

PGF_INTERNAL_DECL void
pgf_pattern_unify(PgfReasoner* rs, PgfClosure* c1, PgfClosure* c2);

#endif

