UPDATE employees set employeeNumber = 1626 where employeeNumber = 1625;
