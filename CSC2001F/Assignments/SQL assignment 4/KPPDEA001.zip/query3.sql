SELECT phone from customers where salesRepEmployeeNumber is null;
