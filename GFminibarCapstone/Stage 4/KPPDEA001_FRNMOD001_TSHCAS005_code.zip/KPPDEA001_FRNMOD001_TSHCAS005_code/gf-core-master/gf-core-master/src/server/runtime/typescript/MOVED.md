# Project moved

The GF TypeScript runtime has been moved to the repository:
<https://github.com/GrammaticalFramework/gf-typescript>

If you are looking for an updated version of the JavaScript runtime,
you should also look there.
